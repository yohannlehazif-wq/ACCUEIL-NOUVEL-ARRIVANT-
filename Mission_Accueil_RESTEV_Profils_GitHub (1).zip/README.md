# Mission Accueil RESTEV - version par profils

Cette version conserve le fonctionnement autonome du jeu et ajoute :
- identité visuelle RESTEV et logo officiel fourni ;
- questions et réponses différentes pour Karim, Léa, Samira et Thomas ;
- 24 situations principales, soit 6 par profil ;
- 4 questions bonus propres aux profils ;
- illustrations locales sans dépendance externe ;
- lien vers www.restev.fr.

## GitHub Pages
Déposez tous les fichiers à la racine du dépôt, sans modifier les noms. Activez ensuite Settings > Pages > Deploy from a branch > main / root.
